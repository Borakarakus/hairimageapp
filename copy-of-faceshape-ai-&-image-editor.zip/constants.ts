
export const AGE_GROUPS = [
  "10-13", "13-18", "18-25", "25-35", "35-45", "45-55", "55+"
];

export const HAIRSTYLE_MODELS: Record<string, string[]> = {
  Oval: [
    "Modern Textured Crop",
    "Sharp Skin Fade Undercut",
    "Classic Side Part",
    "High Volume Quiff",
    "Natural Mid-Length Flow",
    "Messy Spiky Texture",
    "Low Taper Scissor Cut",
    "Slicked Back Modern Fade"
  ],
  Round: [
    "Angular Fringe Crop",
    "Vertical Undercut",
    "Structured Side Part",
    "High Volume Pompadour",
    "Side-Swept Layered Cut",
    "Textured Spiky Top",
    "Modern Faux Hawk",
    "Asymmetric Textured Fringe"
  ],
  Square: [
    "Short Crew Cut",
    "Slicked Back Fade",
    "Executive Side Part",
    "Modern Faux Hawk",
    "Layered Scissor Flow",
    "Short Messy Texture",
    "Buzz Cut with Sharp Lineup",
    "Long Textured Quiff"
  ],
  Rectangle: [
    "Side-Swept Fringe",
    "Low Fade Scissor Cut",
    "Classic Taper Part",
    "Textured Volume Quiff",
    "Relaxed Medium Flow",
    "Layered Tapered Cut",
    "Messy Fringe with Mid Fade",
    "Natural Curled Top"
  ],
  Heart: [
    "Long Messy Fringe",
    "Tapered Side Sweep",
    "Mid-Length Side Part",
    "Textured Bro Flow",
    "Natural Wavy Layers",
    "Soft Textured Crop",
    "Loose Curls with Taper",
    "Slightly Overgrown Taper"
  ],
  Diamond: [
    "Textured Side-Swept Fringe",
    "High Taper Undercut",
    "Layered Classic Side Part",
    "Modern Pompadour Fade",
    "Long Scissor Flow",
    "Textured Quiff Taper",
    "Short Tapered Pompadour",
    "Messy Layered Scissor Cut"
  ]
};

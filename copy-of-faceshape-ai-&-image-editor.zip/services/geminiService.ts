
import { GoogleGenAI, Type } from "@google/genai";
import { FaceAnalysisResult } from "../types";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const analyzeFaceShape = async (base64Image: string): Promise<FaceAnalysisResult> => {
  const ai = getAIClient();
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image.split(',')[1] || base64Image,
          },
        },
        {
          text: `You are a professional facial morphology expert. Analyze this face with extreme precision.
          
          DIAGNOSTIC CRITERIA:
          1. SQUARE: Broad jawline, sharp angles, width of forehead approx equals width of jaw.
          2. ROUND: Height and width are nearly equal, jawline is soft and curved.
          3. OVAL: Balanced, length is 1.5x width, forehead slightly wider than jaw, soft curves.
          4. RECTANGLE: Similar to Square but face is significantly longer.
          5. HEART: Broad forehead, narrow pointed chin.
          6. DIAMOND: Cheekbones are the widest part, narrow forehead and jaw.
          
          Return ONLY a JSON object with the "shape" property. One of: Oval, Round, Square, Rectangle, Heart, Diamond.`,
        },
      ],
    },
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          shape: { type: Type.STRING, description: "The identified face shape" },
        },
        required: ['shape'],
      },
    },
  });

  const text = response.text;
  if (!text) throw new Error("AI analysis failed");
  const parsed = JSON.parse(text);
  return parsed;
};

export const generateHairstyleImage = async (
  styleName: string, 
  faceShape: string, 
  ageGroup: string,
  userImageBase64: string
): Promise<string> => {
  const ai = getAIClient();
  
  // Using gemini-2.5-flash-image which doesn't require mandatory key selection step
  const prompt = `Generate a professional high-quality studio headshot portrait of a person who looks like the individual in the provided image.
  APPLY HAIRSTYLE: ${styleName}.
  The person should be in the ${ageGroup} age group and keep the ${faceShape} face shape structure.
  The hairstyle must be clearly visible and modern. 
  Maintain the skin tone and ethnic features from the reference image.
  Neutral background, cinematic studio lighting, hyper-realistic details. No accessories like hats.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: userImageBase64.split(',')[1] || userImageBase64,
          },
        },
        { text: prompt }
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "3:4"
      },
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  }

  throw new Error("Could not generate image");
};

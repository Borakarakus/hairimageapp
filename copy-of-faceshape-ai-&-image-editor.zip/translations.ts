
export const translations = {
  tr: {
    title: "Yüz Şekli AI",
    selectLanguage: "Dil ve Tema Seçimi",
    selectAge: "Yaş Grubunuzu Seçin",
    uploadTitle: "Fotoğrafınızı Yükleyin",
    uploadDesc: "Yüz şeklinizi analiz edip size en uygun modern saç modellerini önermemiz için net bir fotoğraf yükleyin.",
    btnUpload: "Fotoğraf Seç",
    btnAnalyze: "Analiz Et",
    analyzing: "Analiz Ediliyor...",
    resultTitle: "Yüz Tipi",
    reset: "Baştan Başla",
    themeLight: "Açık Mod",
    themeDark: "Koyu Mod",
    ageGroups: {
      "10-13": "10-13 Yaş",
      "13-18": "13-18 Yaş",
      "18-25": "18-25 Yaş",
      "25-35": "25-35 Yaş",
      "35-45": "35-45 Yaş",
      "45-55": "45-55 Yaş",
      "55+": "55+ Yaş"
    },
    shapes: {
      Oval: "Oval",
      Round: "Yuvarlak",
      Square: "Kare",
      Rectangle: "Dikdörtgen",
      Heart: "Kalp",
      Diamond: "Elmas"
    }
  },
  en: {
    title: "FaceShape AI",
    selectLanguage: "Language & Theme Selection",
    selectAge: "Select Your Age Group",
    uploadTitle: "Upload Your Photo",
    uploadDesc: "Upload a clear photo so we can analyze your face shape and recommend 8 modern hairstyles resembling you.",
    btnUpload: "Select Photo",
    btnAnalyze: "Analyze",
    analyzing: "Analyzing...",
    resultTitle: "Face Shape",
    reset: "Start Over",
    themeLight: "Light Mode",
    themeDark: "Dark Mode",
    ageGroups: {
      "10-13": "Ages 10-13",
      "13-18": "Ages 13-18",
      "18-25": "Ages 18-25",
      "25-35": "Ages 25-35",
      "35-45": "Ages 35-45",
      "45-55": "Ages 45-55",
      "55+": "Ages 55+"
    },
    shapes: {
      Oval: "Oval",
      Round: "Round",
      Square: "Square",
      Rectangle: "Rectangle",
      Heart: "Heart",
      Diamond: "Diamond"
    }
  }
};

export type Language = 'tr' | 'en';

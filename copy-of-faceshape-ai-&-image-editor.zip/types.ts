
import { Language } from './translations';

export interface Recommendation {
  name: string;
  imageUrl: string;
}

export interface FaceAnalysisResult {
  shape: string;
}

export interface AppState {
  language: Language | null;
  ageGroup: string | null;
  step: 'language' | 'age' | 'upload' | 'analyzing' | 'result';
  originalImage: string | null;
  result: FaceAnalysisResult | null;
  recommendations: Recommendation[];
  generationProgress: number; // 0 to 8
  error: string | null;
  theme: 'light' | 'dark';
}
